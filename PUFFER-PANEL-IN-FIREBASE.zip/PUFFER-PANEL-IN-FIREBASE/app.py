from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import json
import os
import subprocess
import asyncio
import threading
from datetime import datetime
import bcrypt
import secrets

app = Flask(__name__)
app.secret_key = 'unixnodes-cpanel-secret-key-2024'

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# User class for authentication
class User(UserMixin):
    def __init__(self, id, username, role='user'):
        self.id = id
        self.username = username
        self.role = role

# Load settings
def load_settings():
    try:
        with open('settings.json', 'r') as f:
            content = f.read().strip()
            if not content:
                raise ValueError("Empty file")
            return json.loads(content)
    except (FileNotFoundError, json.JSONDecodeError, ValueError):
        # Create default settings if file doesn't exist or is invalid
        default_settings = {
            "admin_username": "admin",
            "admin_password": "admin123",
            "discord_token": "YOUR_DISCORD_TOKEN_HERE",
            "main_admin_id": "1210291131301101618",
            "vps_user_role_id": "1210291131301101618",
            "default_storage_pool": "default",
            "cpu_threshold": 90,
            "ram_threshold": 90,
            "check_interval": 600
        }
        save_settings(default_settings)
        return default_settings

def save_settings(settings):
    with open('settings.json', 'w') as f:
        json.dump(settings, f, indent=4)

# Load users data
def load_users():
    try:
        with open('users.json', 'r') as f:
            content = f.read().strip()
            if not content:
                raise ValueError("Empty file")
            return json.loads(content)
    except (FileNotFoundError, json.JSONDecodeError, ValueError):
        # Create default admin user
        default_users = {
            "admin": {
                "password": bcrypt.hashpw("admin123".encode('utf-8'), bcrypt.gensalt()).decode('utf-8'),
                "role": "admin",
                "created_at": datetime.now().isoformat()
            }
        }
        save_users(default_users)
        return default_users

def save_users(users):
    with open('users.json', 'w') as f:
        json.dump(users, f, indent=4)

# Load VPS data
def load_vps_data():
    try:
        with open('vps_data.json', 'r') as f:
            content = f.read().strip()
            if not content:
                return {}
            return json.loads(content)
    except (FileNotFoundError, json.JSONDecodeError, ValueError):
        return {}

def save_vps_data(data):
    with open('vps_data.json', 'w') as f:
        json.dump(data, f, indent=4)

def load_admin_data():
    try:
        with open('admin_data.json', 'r') as f:
            content = f.read().strip()
            if not content:
                return {"admins": []}
            return json.loads(content)
    except (FileNotFoundError, json.JSONDecodeError, ValueError):
        return {"admins": []}

@login_manager.user_loader
def load_user(user_id):
    users = load_users()
    if user_id in users:
        return User(user_id, user_id, users[user_id]['role'])
    return None

# Initialize data files
def initialize_data_files():
    """Initialize all required data files with proper content"""
    # Initialize settings
    if not os.path.exists('settings.json'):
        load_settings()

    # Initialize users
    if not os.path.exists('users.json'):
        load_users()
    else:
        # Check if users.json is valid, if not recreate it
        try:
            with open('users.json', 'r') as f:
                content = f.read().strip()
                if not content:
                    raise ValueError("Empty file")
                json.loads(content)
        except (json.JSONDecodeError, ValueError):
            print("users.json is corrupted, recreating...")
            load_users()

    # Initialize vps_data
    if not os.path.exists('vps_data.json'):
        save_vps_data({})
    else:
        # Check if vps_data.json is valid
        try:
            with open('vps_data.json', 'r') as f:
                content = f.read().strip()
                if not content:
                    save_vps_data({})
                else:
                    json.loads(content)
        except json.JSONDecodeError:
            print("vps_data.json is corrupted, recreating...")
            save_vps_data({})

    # Initialize admin_data
    if not os.path.exists('admin_data.json'):
        with open('admin_data.json', 'w') as f:
            json.dump({"admins": []}, f, indent=4)

# LXC Command Execution
def run_lxc_sync(command, timeout=120):
    """Run LXC command synchronously"""
    try:
        result = subprocess.run(command.split(), capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            raise Exception(result.stderr.strip())
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        raise Exception(f"Command timed out after {timeout} seconds")
    except Exception as e:
        raise Exception(f"LXC Error: {str(e)}")

# Container status functions
def get_container_status(container_name):
    """Get the status of the LXC container"""
    try:
        result = run_lxc_sync(f"lxc info {container_name}")
        for line in result.splitlines():
            if line.startswith("Status: "):
                return line.split(": ", 1)[1].strip()
        return "Unknown"
    except Exception:
        return "Unknown"

def get_container_stats(container_name):
    """Get container statistics"""
    try:
        status = get_container_status(container_name)

        # Get CPU usage
        cpu_usage = "0%"
        try:
            cpu_result = run_lxc_sync(f"lxc exec {container_name} -- top -bn1")
            for line in cpu_result.splitlines():
                if '%Cpu(s):' in line:
                    words = line.split()
                    for i, word in enumerate(words):
                        if word == 'id,':
                            idle_str = words[i-1].rstrip(',')
                            try:
                                idle = float(idle_str)
                                usage = 100.0 - idle
                                cpu_usage = f"{usage:.1f}%"
                            except ValueError:
                                pass
                    break
        except:
            cpu_usage = "Error"

        # Get memory usage
        memory_usage = "Unknown"
        try:
            mem_result = run_lxc_sync(f"lxc exec {container_name} -- free -m")
            lines = mem_result.splitlines()
            if len(lines) > 1:
                parts = lines[1].split()
                if len(parts) >= 3:
                    total = int(parts[1])
                    used = int(parts[2])
                    usage_pct = (used / total * 100) if total > 0 else 0
                    memory_usage = f"{used}/{total} MB ({usage_pct:.1f}%)"
        except:
            memory_usage = "Error"

        # Get disk usage
        disk_usage = "Unknown"
        try:
            disk_result = run_lxc_sync(f"lxc exec {container_name} -- df -h /")
            for line in disk_result.splitlines():
                if '/dev/' in line and ' /' in line:
                    parts = line.split()
                    if len(parts) >= 5:
                        used = parts[2]
                        size = parts[1]
                        perc = parts[4]
                        disk_usage = f"{used}/{size} ({perc})"
                    break
        except:
            disk_usage = "Error"

        return {
            'status': status,
            'cpu_usage': cpu_usage,
            'memory_usage': memory_usage,
            'disk_usage': disk_usage
        }
    except Exception as e:
        return {
            'status': 'Error',
            'cpu_usage': 'Error',
            'memory_usage': 'Error',
            'disk_usage': 'Error'
        }

# Routes
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        users = load_users()

        if username in users and bcrypt.checkpw(password.encode('utf-8'), users[username]['password'].encode('utf-8')):
            user = User(username, username, users[username]['role'])
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials', 'error')

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    settings = load_settings()
    vps_data = load_vps_data()

    # Calculate statistics
    total_users = len(vps_data)
    total_vps = sum(len(vps_list) for vps_list in vps_data.values())
    running_vps = 0
    suspended_vps = 0

    for vps_list in vps_data.values():
        for vps in vps_list:
            if vps.get('status') == 'running' and not vps.get('suspended', False):
                running_vps += 1
            elif vps.get('suspended', False):
                suspended_vps += 1

    # Get system info
    system_info = get_system_info()

    # Get user's VPS if not admin
    user_vps = []
    if current_user.role != 'admin':
        user_vps = vps_data.get(current_user.id, [])

    return render_template('dashboard.html',
                         total_users=total_users,
                         total_vps=total_vps,
                         running_vps=running_vps,
                         suspended_vps=suspended_vps,
                         system_info=system_info,
                         settings=settings,
                         user_vps=user_vps,
                         current_user=current_user)

@app.route('/users')
@login_required
def users():
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('dashboard'))

    vps_data = load_vps_data()
    users_data = load_users()

    users_list = []
    for user_id, user_info in users_data.items():
        vps_list = vps_data.get(user_id, [])
        user_data = {
            'username': user_id,
            'role': user_info.get('role', 'user'),
            'created_at': user_info.get('created_at', 'Unknown'),
            'vps_count': len(vps_list),
            'running_vps': sum(1 for vps in vps_list if vps.get('status') == 'running' and not vps.get('suspended', False)),
            'suspended_vps': sum(1 for vps in vps_list if vps.get('suspended', False)),
            'total_ram': sum(int(vps['ram'].replace('GB', '')) for vps in vps_list),
            'total_cpu': sum(int(vps['cpu']) for vps in vps_list),
            'total_storage': sum(int(vps['storage'].replace('GB', '')) for vps in vps_list),
            'vps_details': vps_list
        }
        users_list.append(user_data)

    return render_template('users.html', users=users_list, current_user=current_user)

@app.route('/add_user', methods=['POST'])
@login_required
def add_user():
    if current_user.role != 'admin':
        return jsonify({'error': 'Access denied'}), 403

    username = request.form.get('username')
    password = request.form.get('password')
    role = request.form.get('role', 'user')

    if not username or not password:
        flash('Username and password are required', 'error')
        return redirect(url_for('users'))

    users = load_users()

    if username in users:
        flash('User already exists', 'error')
        return redirect(url_for('users'))

    # Hash password
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    users[username] = {
        'password': hashed_password,
        'role': role,
        'created_at': datetime.now().isoformat()
    }

    save_users(users)
    flash(f'User {username} added successfully as {role}', 'success')
    return redirect(url_for('users'))

@app.route('/delete_user/<username>')
@login_required
def delete_user(username):
    if current_user.role != 'admin':
        flash('Access denied', 'error')
        return redirect(url_for('users'))

    if username == 'admin':
        flash('Cannot delete admin user', 'error')
        return redirect(url_for('users'))

    users = load_users()
    vps_data = load_vps_data()

    if username in users:
        del users[username]
        save_users(users)

        # Delete user's VPS data
        if username in vps_data:
            # Stop and delete all containers for this user
            for vps in vps_data[username]:
                try:
                    run_lxc_sync(f"lxc stop {vps['container_name']} --force")
                    run_lxc_sync(f"lxc delete {vps['container_name']} --force")
                except Exception as e:
                    print(f"Error deleting container {vps['container_name']}: {e}")

            del vps_data[username]
            save_vps_data(vps_data)

        flash(f'User {username} deleted successfully', 'success')
    else:
        flash('User not found', 'error')

    return redirect(url_for('users'))

@app.route('/vps_management')
@login_required
def vps_management():
    vps_data = load_vps_data()

    if current_user.role == 'admin':
        # Admin can see all VPS
        all_vps = []
        for user_id, vps_list in vps_data.items():
            for vps in vps_list:
                vps['owner'] = user_id
                all_vps.append(vps)
        user_vps = all_vps
    else:
        # Regular user can only see their VPS
        user_vps = vps_data.get(current_user.id, [])

    # Get current stats for each VPS
    for vps in user_vps:
        stats = get_container_stats(vps['container_name'])
        vps['current_status'] = stats['status']
        vps['cpu_usage'] = stats['cpu_usage']
        vps['memory_usage'] = stats['memory_usage']
        vps['disk_usage'] = stats['disk_usage']

    return render_template('vps_management.html', vps_list=user_vps, current_user=current_user)

@app.route('/create_vps', methods=['POST'])
@login_required
def create_vps():
    try:
        if current_user.role != 'admin':
            return jsonify({'error': 'Access denied'}), 403

        username = request.form.get('username')
        ram = int(request.form.get('ram'))
        cpu = int(request.form.get('cpu'))
        disk = int(request.form.get('disk'))

        if not username or ram <= 0 or cpu <= 0 or disk <= 0:
            flash('Invalid parameters', 'error')
            return redirect(url_for('vps_management'))

        users = load_users()
        if username not in users:
            flash('User does not exist', 'error')
            return redirect(url_for('vps_management'))

        vps_data = load_vps_data()

        if username not in vps_data:
            vps_data[username] = []

        vps_count = len(vps_data[username]) + 1
        container_name = f"unixnodes-vps-{username}-{vps_count}"
        ram_mb = ram * 1024

        # Create the VPS container
        try:
            run_lxc_sync(f"lxc init ubuntu:22.04 {container_name} --storage default")
            run_lxc_sync(f"lxc config set {container_name} limits.memory {ram_mb}MB")
            run_lxc_sync(f"lxc config set {container_name} limits.cpu {cpu}")
            run_lxc_sync(f"lxc config device set {container_name} root size {disk}GB")
            run_lxc_sync(f"lxc start {container_name}")
        except Exception as e:
            flash(f'Error creating VPS: {str(e)}', 'error')
            return redirect(url_for('vps_management'))

        config_str = f"{ram}GB RAM / {cpu} CPU / {disk}GB Disk"
        new_vps = {
            "container_name": container_name,
            "ram": f"{ram}GB",
            "cpu": str(cpu),
            "storage": f"{disk}GB",
            "config": config_str,
            "status": "running",
            "suspended": False,
            "suspension_history": [],
            "created_at": datetime.now().isoformat(),
            "shared_with": []
        }

        vps_data[username].append(new_vps)

        # Save updated data
        save_vps_data(vps_data)

        flash(f'VPS created successfully for user {username}', 'success')
        return redirect(url_for('vps_management'))

    except Exception as e:
        flash(f'Error creating VPS: {str(e)}', 'error')
        return redirect(url_for('vps_management'))

@app.route('/vps_action/<container_name>/<action>')
@login_required
def vps_action(container_name, action):
    try:
        vps_data = load_vps_data()

        # Find the VPS and check permissions
        vps_found = None
        owner = None

        for user_id, vps_list in vps_data.items():
            for vps in vps_list:
                if vps['container_name'] == container_name:
                    vps_found = vps
                    owner = user_id
                    break
            if vps_found:
                break

        if not vps_found:
            flash('VPS not found', 'error')
            return redirect(url_for('vps_management'))

        # Check permissions
        if current_user.role != 'admin' and current_user.id != owner:
            flash('Access denied', 'error')
            return redirect(url_for('vps_management'))

        # Perform action
        if action == 'start':
            run_lxc_sync(f"lxc start {container_name}")
            vps_found['status'] = 'running'
            vps_found['suspended'] = False
            flash(f'VPS {container_name} started successfully', 'success')

        elif action == 'stop':
            run_lxc_sync(f"lxc stop {container_name}")
            vps_found['status'] = 'stopped'
            flash(f'VPS {container_name} stopped successfully', 'success')

        elif action == 'restart':
            run_lxc_sync(f"lxc restart {container_name}")
            vps_found['status'] = 'running'
            vps_found['suspended'] = False
            flash(f'VPS {container_name} restarted successfully', 'success')

        elif action == 'suspend':
            run_lxc_sync(f"lxc stop {container_name}")
            vps_found['status'] = 'suspended'
            vps_found['suspended'] = True
            if 'suspension_history' not in vps_found:
                vps_found['suspension_history'] = []
            vps_found['suspension_history'].append({
                'time': datetime.now().isoformat(),
                'reason': 'Manual suspension',
                'by': current_user.id
            })
            flash(f'VPS {container_name} suspended successfully', 'success')

        elif action == 'unsuspend':
            run_lxc_sync(f"lxc start {container_name}")
            vps_found['status'] = 'running'
            vps_found['suspended'] = False
            flash(f'VPS {container_name} unsuspended successfully', 'success')

        # Save updated data
        save_vps_data(vps_data)

    except Exception as e:
        flash(f'Error performing action: {str(e)}', 'error')

    return redirect(url_for('vps_management'))

@app.route('/delete_vps/<container_name>')
@login_required
def delete_vps(container_name):
    try:
        if current_user.role != 'admin':
            flash('Access denied', 'error')
            return redirect(url_for('vps_management'))

        vps_data = load_vps_data()

        # Find and delete the VPS
        for user_id, vps_list in vps_data.items():
            for i, vps in enumerate(vps_list):
                if vps['container_name'] == container_name:
                    # Stop and delete container
                    try:
                        run_lxc_sync(f"lxc stop {container_name} --force")
                        run_lxc_sync(f"lxc delete {container_name} --force")
                    except Exception as e:
                        print(f"Error deleting container: {e}")

                    # Remove from data
                    del vps_list[i]
                    if not vps_list:
                        del vps_data[user_id]

                    # Save updated data
                    save_vps_data(vps_data)

                    flash(f'VPS {container_name} deleted successfully', 'success')
                    return redirect(url_for('vps_management'))

        flash('VPS not found', 'error')

    except Exception as e:
        flash(f'Error deleting VPS: {str(e)}', 'error')

    return redirect(url_for('vps_management'))

@app.route('/vps_stats/<container_name>')
@login_required
def vps_stats(container_name):
    try:
        stats = get_container_stats(container_name)
        return jsonify(stats)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if current_user.role != 'admin':
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('dashboard'))

    settings_data = load_settings()

    if request.method == 'POST':
        try:
            # Update settings
            settings_data['admin_username'] = request.form.get('admin_username')
            new_password = request.form.get('admin_password')
            if new_password:
                users = load_users()
                users['admin']['password'] = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
                save_users(users)

            settings_data['discord_token'] = request.form.get('discord_token')
            settings_data['main_admin_id'] = request.form.get('main_admin_id')
            settings_data['vps_user_role_id'] = request.form.get('vps_user_role_id')
            settings_data['default_storage_pool'] = request.form.get('default_storage_pool')
            settings_data['cpu_threshold'] = int(request.form.get('cpu_threshold'))
            settings_data['ram_threshold'] = int(request.form.get('ram_threshold'))
            settings_data['check_interval'] = int(request.form.get('check_interval'))

            save_settings(settings_data)
            flash('Settings updated successfully', 'success')
        except Exception as e:
            flash(f'Error updating settings: {str(e)}', 'error')

    return render_template('settings.html', settings=settings_data, current_user=current_user)

@app.route('/api/system_stats')
@login_required
def system_stats():
    vps_data = load_vps_data()

    stats = {
        'total_users': len(vps_data),
        'total_vps': sum(len(vps_list) for vps_list in vps_data.values()),
        'running_vps': sum(1 for vps_list in vps_data.values() for vps in vps_list 
                          if vps.get('status') == 'running' and not vps.get('suspended', False)),
        'suspended_vps': sum(1 for vps_list in vps_data.values() for vps in vps_list 
                            if vps.get('suspended', False)),
        'total_ram': sum(int(vps['ram'].replace('GB', '')) for vps_list in vps_data.values() for vps in vps_list),
        'total_cpu': sum(int(vps['cpu']) for vps_list in vps_data.values() for vps in vps_list),
        'total_storage': sum(int(vps['storage'].replace('GB', '')) for vps_list in vps_data.values() for vps in vps_list)
    }

    return jsonify(stats)

def get_system_info():
    """Get system information"""
    try:
        # Get hostname
        hostname = subprocess.run(['hostname'], capture_output=True, text=True).stdout.strip()

        # Get uptime
        uptime = subprocess.run(['uptime', '-p'], capture_output=True, text=True).stdout.strip()

        return {
            'hostname': hostname,
            'uptime': uptime,
            'cpu_info': 'Available in detailed view',
            'memory_info': 'Available in detailed view'
        }
    except Exception as e:
        return {
            'hostname': 'Unknown',
            'uptime': 'Unknown',
            'cpu_info': 'Error fetching system info',
            'memory_info': 'Error fetching system info'
        }

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return render_template('error.html', error='Page not found'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('error.html', error='Internal server error'), 500

if __name__ == '__main__':
    # Initialize all data files
    initialize_data_files()

    print("UnixNodes Admin Panel starting...")
    print("Access the panel at: http://localhost:5000")
    print("Default admin credentials: admin / admin123")

    app.run(host='0.0.0.0', port=5000, debug=True)