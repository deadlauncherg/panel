# HVM VPS Panel

## Overview
This is a Flask-based VPS management panel that allows users to create and manage virtual private servers (VPS) using Docker containers. The panel provides a web interface for creating, monitoring, and managing VPS instances.

**Note:** This application requires Docker to function properly. Docker is not available in the Replit environment, so the VPS creation features will not work. However, the web interface and authentication system are fully functional for demonstration purposes.

## Current State
- **Status:** Running on port 5000
- **Framework:** Flask with Flask-SocketIO
- **Database:** SQLite
- **Authentication:** Flask-Login with admin/user roles
- **Default Admin Credentials:** 
  - Username: admin
  - Password: admin123456

## Project Architecture

### Main Components
1. **Flask Application** (`hvm/hvm.py`) - Main application server
2. **Templates** (`hvm/templates/`) - HTML templates for the web interface
3. **Database** - SQLite database (hvm_panel.db)
4. **Configuration** - `.env` file in hvm directory

### Key Features
- User authentication and authorization
- VPS instance management (requires Docker)
- Real-time monitoring via WebSockets
- Resource usage statistics
- Anti-mining detection
- Automatic VPS expiration management

### Directory Structure
```
.
├── hvm/
│   ├── hvm.py           # Main Flask application
│   ├── requirements.txt # Python dependencies
│   ├── .env            # Configuration file
│   └── templates/      # HTML templates
├── .gitignore          # Python gitignore patterns
└── replit.md          # This file
```

## Recent Changes
- **2025-10-03:** Initial setup for Replit environment
  - Configured server to run on port 5000
  - Enabled debug mode for development
  - Installed all Python dependencies
  - Set up Flask workflow
  - Added .gitignore for Python project

## Configuration
The application is configured via environment variables in `hvm/.env`:
- `SERVER_PORT=5000` - Server port (must be 5000 for Replit)
- `DEBUG=True` - Debug mode enabled
- `ADMIN_USERNAME=admin` - Admin username
- `ADMIN_PASSWORD=admin123456` - Admin password
- Other settings for VPS limits, Docker configuration, etc.

## Known Limitations
1. **Docker Unavailable:** The Replit environment doesn't support Docker, so VPS creation and management features won't work
2. **Database Errors:** Some database cursor errors may appear in logs due to threading
3. **Deprecation Warnings:** Paramiko library shows TripleDES deprecation warnings

## Development Notes
- The application uses SQLite for data storage
- WebSocket support via Flask-SocketIO for real-time updates
- Admin interface accessible after login
- User registration available for creating new accounts

## Running Locally
If running outside Replit with Docker available:
1. Ensure Docker is installed and running
2. Update `hvm/.env` with appropriate configuration
3. Run: `python hvm/hvm.py`
4. Access at: http://localhost:5000
