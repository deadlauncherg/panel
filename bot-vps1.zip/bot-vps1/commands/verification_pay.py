import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import os
from utils.database import db

class VerifyPayment(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.oxapay_merchant_key = os.getenv("OXAPAY_MERCHANT_KEY")

    @app_commands.command(name="verify_payment", description="Manually verify a payment and attribute credits.")
    @app_commands.guild_only()
    @app_commands.describe(track_id="The OxaPay payment tracking ID")
    async def verify_payment(self, interaction: discord.Interaction, track_id: str):
        if not self.oxapay_merchant_key:
            await interaction.response.send_message("The payment configuration is not complete. Please contact an administrator.", ephemeral=True)
            return

        transaction = db.get_transaction(track_id)

        if not transaction:
            await interaction.response.send_message("This payment ID is invalid.", ephemeral=True)
            return

        _, user_id, credits, _, credits_attributed = transaction

        if credits_attributed:
            await interaction.response.send_message("Credits for this payment have already been attributed.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        headers = {
            'merchant_api_key': self.oxapay_merchant_key,
            'Content-Type': 'application/json'
        }
        url = f'https://api.oxapay.com/v1/payment/{track_id}'

        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url, headers=headers) as resp:
                    if resp.status == 200:
                        response_data = await resp.json()
                        payment_data = response_data.get('data', {})
                        if payment_data.get('status') == 'paid':
                            compensation = 1
                            total_credits = credits + compensation
                            db.add_credits(user_id, total_credits)
                            db.mark_transaction_as_attributed(track_id)
                            await interaction.followup.send(f"{total_credits} credits (including {compensation} as compensation) have been added to the user's account.", ephemeral=True)
                            try:
                                user = await self.bot.fetch_user(user_id)
                                await user.send(f"Your payment has been manually verified. {total_credits} credits have been added to your account.")
                            except discord.Forbidden:
                                pass
                        else:
                            await interaction.followup.send(f"The payment has not yet been confirmed by OxaPay. Status: {data.get('status')}", ephemeral=True)
                    else:
                        await interaction.followup.send(f"OxaPay API Error: {resp.status}", ephemeral=True)
            except Exception as e:
                await interaction.followup.send(f"An error occurred: {e}", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(VerifyPayment(bot))
