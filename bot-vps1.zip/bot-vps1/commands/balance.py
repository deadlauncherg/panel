import discord
from discord.ext import commands
from discord import app_commands
from utils.database import db

class Balance(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="balance", description="Displays your credit balance")
    @app_commands.guild_only()
    async def balance(self, interaction: discord.Interaction):
        user_id = interaction.user.id
        balance = db.get_balance(user_id)
        embed = discord.Embed(title="Your Balance", description=f"You currently have **{balance}** credits.", color=discord.Color.blue())
        await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(Balance(bot))
